import { createFileRoute } from "@tanstack/react-router";
import { AnimatePresence, motion } from "motion/react";
import { useState } from "react";
import { Check, Mail, Phone, Send } from "lucide-react";

import { Layout, PageHero } from "@/components/site/Layout";
import { RevealGroup, RevealItem } from "@/components/site/Reveal";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact & Ordering — Thiaw Agro Élevage" },
      {
        name: "description",
        content:
          "Order chickens, fruits and vegetables from Thiaw Agro Élevage, or ask about investing. Call 901-319-9938 or send your order details.",
      },
      { property: "og:title", content: "Contact & Ordering — Thiaw Agro Élevage" },
      {
        property: "og:description",
        content: "Send your order or investment enquiry to Thiaw Agro Élevage.",
      },
    ],
  }),
  component: Contact,
});

const interests = ["Chickens", "Vegetables", "Fruits", "Agriculture", "Investing"];

function Field({
  label,
  name,
  type = "text",
  required = true,
  placeholder,
}: {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
  placeholder?: string;
}) {
  return (
    <label className="group block">
      <span className="text-sm font-semibold text-secondary">{label}</span>
      <div className="relative mt-2">
        <input
          type={type}
          name={name}
          required={required}
          placeholder={placeholder}
          className="w-full rounded-xl border border-border bg-card px-4 py-3 text-secondary outline-none transition-colors placeholder:text-muted-foreground/70 focus:border-primary"
        />
        <span className="pointer-events-none absolute bottom-0 left-0 h-[2px] w-full origin-left scale-x-0 bg-[image:var(--gradient-ember)] transition-transform duration-500 group-focus-within:scale-x-100" />
      </div>
    </label>
  );
}

function Contact() {
  const [sent, setSent] = useState(false);
  const [interest, setInterest] = useState<string>("Chickens");

  return (
    <Layout>
      <PageHero
        eyebrow="Contact & ordering"
        title={
          <>
            Tell us what you need,
            <br />
            <span className="text-ember">we will harvest for it.</span>
          </>
        }
        lead="Orders, wholesale enquiries and investment questions all land in the same place — and get a real answer."
      />

      <section className="mx-auto grid max-w-6xl gap-8 px-5 py-12 lg:grid-cols-[1.15fr_0.85fr]">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="surface-card relative overflow-hidden rounded-[2rem] p-8"
        >
          <AnimatePresence mode="wait">
            {sent ? (
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.94 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                className="flex min-h-[26rem] flex-col items-center justify-center text-center"
              >
                <motion.span
                  initial={{ scale: 0, rotate: -30 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ type: "spring", stiffness: 220, damping: 14 }}
                  className="flex size-20 items-center justify-center rounded-full bg-[image:var(--gradient-ember)] text-primary-foreground"
                >
                  <Check className="size-9" />
                </motion.span>
                <h2 className="mt-6 text-3xl font-black text-secondary">Order received</h2>
                <p className="mt-3 max-w-sm text-muted-foreground">
                  Thank you — we will get back to you shortly with availability and pricing.
                </p>
                <button
                  type="button"
                  onClick={() => setSent(false)}
                  className="mt-7 rounded-full border border-secondary/30 px-5 py-2.5 text-sm font-semibold text-secondary transition-colors hover:bg-secondary hover:text-secondary-foreground"
                >
                  Send another
                </button>
              </motion.div>
            ) : (
              <motion.form
                key="form"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onSubmit={(event) => {
                  event.preventDefault();
                  setSent(true);
                }}
                className="space-y-5"
              >
                <div className="grid gap-5 sm:grid-cols-2">
                  <Field label="Full name" name="name" placeholder="Your name" />
                  <Field label="Phone" name="phone" type="tel" placeholder="Best number" />
                </div>
                <Field label="Email" name="email" type="email" placeholder="you@email.com" />

                <div>
                  <span className="text-sm font-semibold text-secondary">I'm interested in</span>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {interests.map((item) => (
                      <motion.button
                        key={item}
                        type="button"
                        whileTap={{ scale: 0.94 }}
                        onClick={() => setInterest(item)}
                        className={`rounded-full border px-4 py-2 text-sm font-medium transition-colors ${
                          interest === item
                            ? "border-primary bg-primary text-primary-foreground"
                            : "border-border bg-card text-secondary hover:border-primary"
                        }`}
                      >
                        {item}
                      </motion.button>
                    ))}
                  </div>
                </div>

                <label className="group block">
                  <span className="text-sm font-semibold text-secondary">
                    Order details or message
                  </span>
                  <div className="relative mt-2">
                    <textarea
                      name="message"
                      rows={5}
                      required
                      placeholder="Quantities, delivery date, or your investment question…"
                      className="w-full rounded-xl border border-border bg-card px-4 py-3 text-secondary outline-none transition-colors placeholder:text-muted-foreground/70 focus:border-primary"
                    />
                    <span className="pointer-events-none absolute bottom-1.5 left-0 h-[2px] w-full origin-left scale-x-0 bg-[image:var(--gradient-ember)] transition-transform duration-500 group-focus-within:scale-x-100" />
                  </div>
                </label>

                <motion.button
                  type="submit"
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3.5 font-semibold text-primary-foreground shadow-[var(--shadow-lift)]"
                >
                  Send order
                  <Send className="size-4" />
                </motion.button>
              </motion.form>
            )}
          </AnimatePresence>
        </motion.div>

        <RevealGroup className="space-y-5">
          <RevealItem>
            <div className="surface-card rounded-3xl p-7">
              <p className="eyebrow">Direct line</p>
              <a
                href="tel:+19013199938"
                className="mt-3 flex items-center gap-2 text-lg font-bold text-secondary"
              >
                <Phone className="size-5 text-primary" /> 901-319-9938
              </a>
              <a
                href="mailto:thiaw@att.net"
                className="mt-2 flex items-center gap-2 text-lg font-bold text-secondary"
              >
                <Mail className="size-5 text-primary" /> thiaw@att.net
              </a>
            </div>
          </RevealItem>
          <RevealItem>
            <div className="rounded-3xl bg-[image:var(--gradient-olive)] p-7 text-secondary-foreground">
              <h2 className="font-display text-xl font-bold">Wholesale & restaurants</h2>
              <p className="mt-2 text-sm opacity-90">
                Share your weekly volume and we will build a standing delivery schedule with fixed
                pricing.
              </p>
            </div>
          </RevealItem>
          <RevealItem>
            <div className="surface-card rounded-3xl p-7">
              <h2 className="font-display text-xl font-bold text-secondary">Response time</h2>
              <p className="mt-2 text-sm text-muted-foreground">
                Most orders and enquiries are answered within one business day.
              </p>
            </div>
          </RevealItem>
        </RevealGroup>
      </section>
    </Layout>
  );
}
