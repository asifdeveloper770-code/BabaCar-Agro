import { createFileRoute } from "@tanstack/react-router";

import { Layout, PageHero } from "@/components/site/Layout";
import { RevealGroup, RevealItem } from "@/components/site/Reveal";
import { TiltCard } from "@/components/site/TiltCard";
import farm from "@/assets/farm-landscape.jpg";
import owner from "@/assets/owner-portrait.jpg";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Us — Thiaw Agro Élevage" },
      {
        name: "description",
        content:
          "The story behind Thiaw Agro Élevage: a family farm raising poultry and growing fruits and vegetables with honest, careful practices.",
      },
      { property: "og:title", content: "About Thiaw Agro Élevage" },
      {
        property: "og:description",
        content: "A family farm built on quality breeding and the taste of the terroir.",
      },
    ],
  }),
  component: About,
});

const chapters = [
  {
    year: "The beginning",
    title: "One coop, one promise",
    copy: "Thiaw Agro Élevage started with a small flock and a refusal to compromise: healthy birds, clean feed, open ground, and full transparency with every buyer.",
  },
  {
    year: "Growing the land",
    title: "From poultry to full harvest",
    copy: "Fruit trees and vegetable beds followed the coops. Today the farm runs mixed agriculture so partners can source several categories from one supplier they already trust.",
  },
  {
    year: "Today",
    title: "Serving kitchens and communities",
    copy: "We supply households, restaurants and resellers with steady volumes and consistent quality — and we keep the availability list updated as the seasons change.",
  },
];

function About() {
  return (
    <Layout>
      <PageHero
        eyebrow="About us"
        title={
          <>
            La qualité d'élevage,
            <br />
            <span className="text-ember">le goût du terroir.</span>
          </>
        }
        lead="Thiaw Agro Élevage is a working farm led by Babacar Thiaw — built on patient breeding, real soil, and relationships that last longer than a single delivery."
      />

      <section className="mx-auto max-w-6xl px-5 py-12">
        <RevealGroup className="grid gap-8 lg:grid-cols-2">
          <RevealItem>
            <TiltCard className="grain-overlay overflow-hidden rounded-3xl border border-border shadow-[var(--shadow-lift)]">
              <img
                src={owner}
                alt="Babacar Thiaw on the farm"
                width={1008}
                height={1312}
                loading="lazy"
                className="h-[26rem] w-full object-cover lg:h-full"
              />
            </TiltCard>
          </RevealItem>
          <div className="space-y-6">
            {chapters.map((chapter) => (
              <RevealItem key={chapter.year}>
                <article className="surface-card rounded-3xl p-7">
                  <p className="eyebrow">{chapter.year}</p>
                  <h2 className="mt-2 text-2xl font-bold text-secondary">{chapter.title}</h2>
                  <p className="mt-3 text-muted-foreground">{chapter.copy}</p>
                </article>
              </RevealItem>
            ))}
          </div>
        </RevealGroup>
      </section>

      <section className="relative mt-6 overflow-hidden">
        <img
          src={farm}
          alt="Farm fields at sunrise"
          width={1600}
          height={900}
          loading="lazy"
          className="h-72 w-full object-cover"
        />
        <div className="absolute inset-0 flex items-center justify-center bg-[image:var(--gradient-olive)]/70">
          <p className="max-w-2xl px-6 text-center font-display text-2xl font-bold text-secondary-foreground sm:text-3xl">
            "Feed people the way you would feed your own family. Everything else follows."
          </p>
        </div>
      </section>
    </Layout>
  );
}
