import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "motion/react";
import { ArrowRight } from "lucide-react";

import { Layout, PageHero } from "@/components/site/Layout";
import { RevealGroup, RevealItem } from "@/components/site/Reveal";
import { TiltCard } from "@/components/site/TiltCard";
import agriculture from "@/assets/product-agriculture.jpg";
import fruits from "@/assets/product-fruits.jpg";
import vegetables from "@/assets/product-vegetables.jpg";
import chickens from "@/assets/product-chickens.jpg";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Products & Service — Thiaw Agro Élevage" },
      {
        name: "description",
        content:
          "Agriculture, fruits, vegetables and chickens from Thiaw Agro Élevage — retail crates for consumers, standing orders for restaurants, and bulk pricing for resellers.",
      },
      { property: "og:title", content: "Products & Service — Thiaw Agro Élevage" },
      {
        property: "og:description",
        content: "Farm-direct supply for consumers, restaurants and resellers.",
      },
    ],
  }),
  component: Services,
});

const products = [
  {
    image: chickens,
    title: "Chickens & Poultry",
    copy: "Live birds and dressed poultry raised on open ground with clean feed.",
    tags: ["Restaurants", "Resellers"],
  },
  {
    image: vegetables,
    title: "Vegetables",
    copy: "Tomatoes, onions, okra and leafy greens harvested to your order schedule.",
    tags: ["Consumers", "Restaurants"],
  },
  {
    image: fruits,
    title: "Fruits",
    copy: "Seasonal fruit picked ripe and crated for market-day freshness.",
    tags: ["Consumers", "Resellers"],
  },
  {
    image: agriculture,
    title: "Agriculture",
    copy: "Field crops and land production, plus supply planning for larger contracts.",
    tags: ["Wholesale", "Partners"],
  },
];

const buyers = [
  {
    title: "Consumers",
    copy: "Family crates and single orders, delivered fresh with clear pricing.",
  },
  {
    title: "Restaurants",
    copy: "Recurring weekly deliveries, consistent grading, and dependable volume.",
  },
  {
    title: "Resellers",
    copy: "Bulk lots, wholesale rates and availability updates before each cycle.",
  },
];

function Services() {
  return (
    <Layout>
      <PageHero
        eyebrow="Service"
        title={
          <>
            Everything we raise,
            <br />
            <span className="text-ember">ready for your order.</span>
          </>
        }
        lead="Whether you are cooking for a family, a dining room, or a market stall, we build the order around how you buy."
      />

      <section className="mx-auto max-w-6xl px-5 py-12">
        <RevealGroup className="grid gap-6 sm:grid-cols-2">
          {products.map((product) => (
            <RevealItem key={product.title}>
              <TiltCard
                intensity={9}
                className="grain-overlay group h-full overflow-hidden rounded-3xl border border-border bg-card shadow-[var(--shadow-soft)]"
              >
                <div className="relative overflow-hidden">
                  <motion.img
                    src={product.image}
                    alt={product.title}
                    width={900}
                    height={1100}
                    loading="lazy"
                    className="h-64 w-full object-cover"
                    whileHover={{ scale: 1.1 }}
                    transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                  />
                  <div className="absolute top-4 left-4 flex gap-2">
                    {product.tags.map((tag) => (
                      <span
                        key={tag}
                        className="rounded-full bg-secondary/85 px-3 py-1 text-xs font-semibold text-secondary-foreground"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="p-7">
                  <h2 className="text-2xl font-bold text-secondary">{product.title}</h2>
                  <p className="mt-2 text-muted-foreground">{product.copy}</p>
                  <Link
                    to="/contact"
                    className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-primary"
                  >
                    Request pricing
                    <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" />
                  </Link>
                </div>
              </TiltCard>
            </RevealItem>
          ))}
        </RevealGroup>
      </section>

      <section className="mx-auto max-w-6xl px-5 pb-8">
        <RevealGroup className="grid gap-5 md:grid-cols-3">
          {buyers.map((buyer) => (
            <RevealItem key={buyer.title}>
              <div className="surface-card h-full rounded-3xl p-7">
                <p className="eyebrow">Built for</p>
                <h3 className="mt-2 text-xl font-bold text-secondary">{buyer.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{buyer.copy}</p>
              </div>
            </RevealItem>
          ))}
        </RevealGroup>
      </section>
    </Layout>
  );
}
