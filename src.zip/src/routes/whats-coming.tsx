import { createFileRoute, Link } from "@tanstack/react-router";
import { motion, useScroll, useSpring } from "motion/react";
import { useRef } from "react";
import { ArrowRight } from "lucide-react";

import { Layout, PageHero } from "@/components/site/Layout";
import { RevealGroup, RevealItem } from "@/components/site/Reveal";

export const Route = createFileRoute("/whats-coming")({
  head: () => ({
    meta: [
      { title: "What is Coming — Invest with Thiaw Agro Élevage" },
      {
        name: "description",
        content:
          "Upcoming expansion at Thiaw Agro Élevage and investment opportunities for immigrants who want a stake in productive farmland and poultry operations.",
      },
      { property: "og:title", content: "What is Coming — Invest with Thiaw Agro Élevage" },
      {
        property: "og:description",
        content: "Expansion phases and investment openings for the diaspora community.",
      },
    ],
  }),
  component: WhatsComing,
});

const phases = [
  {
    tag: "Phase 01",
    title: "Poultry capacity expansion",
    copy: "New coops and a controlled brooding unit to raise steady volume for restaurant contracts year-round.",
  },
  {
    tag: "Phase 02",
    title: "Cold chain & packing shed",
    copy: "On-site chilling and packing so vegetables and poultry reach city buyers at full freshness.",
  },
  {
    tag: "Phase 03",
    title: "Diaspora investment program",
    copy: "Structured shares for immigrants who want to invest back home — transparent reporting, defined returns, real assets on real land.",
  },
  {
    tag: "Phase 04",
    title: "Live availability board",
    copy: "An online view of what is harvested and in stock this week, so buyers order with confidence.",
  },
];

function WhatsComing() {
  const trackRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: trackRef,
    offset: ["start 70%", "end 60%"],
  });
  const scaleY = useSpring(scrollYProgress, { stiffness: 90, damping: 22 });

  return (
    <Layout>
      <PageHero
        eyebrow="What is coming"
        title={
          <>
            The next harvest is
            <br />
            <span className="text-ember">an invitation to invest.</span>
          </>
        }
        lead="We are expanding the farm in clear phases — and opening the door for immigrants who want to build something durable back home."
      />

      <section className="mx-auto max-w-4xl px-5 py-12">
        <div ref={trackRef} className="relative pl-10 sm:pl-14">
          <div className="absolute top-2 bottom-2 left-3 w-[3px] rounded-full bg-border sm:left-5" />
          <motion.div
            style={{ scaleY, originY: 0 }}
            className="absolute top-2 bottom-2 left-3 w-[3px] rounded-full bg-[image:var(--gradient-ember)] sm:left-5"
          />

          <RevealGroup className="space-y-8" amount={0.1}>
            {phases.map((phase) => (
              <RevealItem key={phase.tag}>
                <div className="relative">
                  <motion.span
                    whileInView={{ scale: [0.4, 1.15, 1] }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6 }}
                    className="absolute top-8 -left-[1.9rem] size-4 rounded-full border-2 border-background bg-primary sm:-left-[2.6rem]"
                  />
                  <article className="surface-card rounded-3xl p-7">
                    <p className="eyebrow">{phase.tag}</p>
                    <h2 className="mt-2 text-2xl font-bold text-secondary">{phase.title}</h2>
                    <p className="mt-3 text-muted-foreground">{phase.copy}</p>
                  </article>
                </div>
              </RevealItem>
            ))}
          </RevealGroup>
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-5 pb-6">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="grain-overlay overflow-hidden rounded-[2rem] bg-[image:var(--gradient-ember)] p-10 text-center text-primary-foreground"
        >
          <h2 className="text-3xl font-black sm:text-4xl">Invest in land that works</h2>
          <p className="mx-auto mt-4 max-w-xl opacity-90">
            Tell us how you would like to participate — capital, equipment, or distribution — and we
            will share the current plan and numbers.
          </p>
          <Link
            to="/contact"
            className="mt-7 inline-flex items-center gap-2 rounded-full bg-secondary px-6 py-3 font-semibold text-secondary-foreground transition-transform hover:scale-105"
          >
            Start the conversation
            <ArrowRight className="size-4" />
          </Link>
        </motion.div>
      </section>
    </Layout>
  );
}
