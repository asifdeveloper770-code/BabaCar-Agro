import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import en from "@/i18n/en";
import fr from "@/i18n/fr";
import type { TranslationSchema } from "@/i18n/en";

export type Locale = "en" | "fr" ;

export const LOCALES: Locale[] = ["en", "fr" ];
const STORAGE_KEY = "mob_locale";

const dictionaries: Record<Locale, TranslationSchema> = { en, fr};

function isLocale(value: string | null): value is Locale {
  return value === "en" || value === "fr";
}

// Reads a dotted path like "home.heroTitle" off a nested object.
function getPath(obj: any, path: string): unknown {
  return path.split(".").reduce((acc, key) => (acc == null ? undefined : acc[key]), obj);
}

// Replaces {placeholders} in a translated string with values from `vars`.
function interpolate(template: string, vars?: Record<string, string | number>): string {
  if (!vars) return template;
  return template.replace(/\{(\w+)\}/g, (match, key) => {
    const value = vars[key];
    return value === undefined ? match : String(value);
  });
}

interface LanguageContextValue {
  locale: Locale;
  setLocale: (locale: Locale) => void;
  t: (key: string, vars?: Record<string, string | number>) => string;
}

const LanguageContext = createContext<LanguageContextValue | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  // Always start on "en" so server-rendered HTML and the first client render
  // match exactly. Once mounted, we swap to whatever the user had saved —
  // this happens after hydration so there's no mismatch warning.
  const [locale, setLocaleState] = useState<Locale>("en");
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    const saved = typeof window !== "undefined" ? window.localStorage.getItem(STORAGE_KEY) : null;
    if (isLocale(saved)) {
      setLocaleState(saved);
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    document.documentElement.lang = locale;
  }, [locale, hydrated]);

  const setLocale = (next: Locale) => {
    setLocaleState(next);
    try {
      window.localStorage.setItem(STORAGE_KEY, next);
    } catch {
      // localStorage can fail in private browsing / disabled storage — safe to ignore.
    }
  };

  const t = useMemo(() => {
    return (key: string, vars?: Record<string, string | number>) => {
      const dict = dictionaries[locale];
      const value = getPath(dict, key);
      if (typeof value === "string") return interpolate(value, vars);

      // Fall back to English if a key is somehow missing in the active locale.
      const fallback = getPath(dictionaries.en, key);
      if (typeof fallback === "string") return interpolate(fallback, vars);

      // Last resort: surface the key itself so missing translations are obvious.
      return key;
    };
  }, [locale]);

  const value = useMemo(() => ({ locale, setLocale, t }), [locale, t]);

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLanguage() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useLanguage must be used within a LanguageProvider");
  return ctx;
}
