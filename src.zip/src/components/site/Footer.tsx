import { Link } from "@tanstack/react-router";
import { Mail, Phone } from "lucide-react";
import { useLanguage } from "@/i18n/LanguageContext";


import logo from "@/assets/thiaw-logo.jpeg.asset.json";

export function Footer() {
    const { t } = useLanguage();
  return (
    <footer className="mt-24 border-t border-border bg-[image:var(--gradient-olive)] text-secondary-foreground">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-14 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <div className="flex items-center gap-3">
            <img
              src={logo.url}
              alt="Thiaw Agro Élevage logo"
              width={56}
              height={56}
              loading="lazy"
              className="size-14 rounded-xl object-cover"
            />
            <div>
              <p className="font-display text-lg font-bold">Thiaw Agro Élevage</p>
              <p className="text-sm opacity-80">La qualité d'élevage, le goût du terroir</p>
            </div>
          </div>
          <p className="mt-5 max-w-sm text-sm opacity-80">
            Farm-direct poultry, fruits and vegetables for families, restaurants and resellers —
            grown with care and delivered fresh.
          </p>
        </div>

        <div className="text-sm">
          <p className="mb-3 font-semibold tracking-wide uppercase opacity-70">Explore</p>
          <ul className="space-y-2 opacity-90">
            <li><Link to="/">Home</Link></li>
            <li><Link to="/about">About Us</Link></li>
            <li><Link to="/services">Service</Link></li>
            <li><Link to="/whats-coming">What is Coming</Link></li>
            <li><Link to="/contact">Contact</Link></li>
          </ul>
        </div>

        <div className="text-sm">
          <p className="mb-3 font-semibold tracking-wide uppercase opacity-70">Get in touch</p>
          <a href="tel:+19013199938" className="flex items-center gap-2 opacity-90">
            <Phone className="size-4" /> 901-319-9938
          </a>
          <a href="mailto:thiaw@att.net" className="mt-2 flex items-center gap-2 opacity-90">
            <Mail className="size-4" /> thiaw@att.net
          </a>
        </div>
      </div>
      <div className="border-t border-white/10 py-5 text-center text-xs opacity-70">
        © {new Date().getFullYear()} Thiaw Agro Élevage. All rights reserved.
      </div>
    </footer>
  );
}
